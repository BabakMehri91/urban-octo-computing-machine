/*
Theme Name:           Revision
Theme URI:            https://revision.codesupply.co
Description:          High-Performance WordPress Personal Blog Theme
Documentation URI:    https://support.codesupply.co/documentation/revision/
Author:               Code Supply Co.
Author URI:           https://codesupply.co
Version:              1.0.3
Tested up to:         6.7
Requires at least:    6.0
Requires PHP:         7.0
Tags:                 custom-colors, editor-style, theme-options, custom-menu, sticky-post, right-sidebar, translation-ready
License:              GNU General Public License version 3.0
License URI:          http://www.gnu.org/licenses/gpl-3.0.html
Text Domain:          revision
*/
